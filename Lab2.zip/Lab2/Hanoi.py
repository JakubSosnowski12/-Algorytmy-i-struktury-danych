def hanoi_towers(n, source, auxiliary, target):
    if n % 2 == 0:
        # Jeżeli liczba krążków jest parzysta, zamień drążki docelowy i pomocniczy
        auxiliary, target = target, auxiliary

    def move_disk(source, target):
        print("Przenieś krążek z", source, "na", target)

    def hanoi_recursive(n, source, auxiliary, target):
        if n > 0:
            hanoi_recursive(n - 1, source, target, auxiliary)
            move_disk(source, target)
            hanoi_recursive(n - 1, auxiliary, source, target)

    hanoi_recursive(n, source, auxiliary, target)


hanoi_towers(3, "A", "B", "C")
