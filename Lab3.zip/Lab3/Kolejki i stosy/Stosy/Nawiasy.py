class StackObject:
    def __init__(self, data):
        self.data = data
        self.next = None

class Stack:
        def __init__(self):
            self.top = None
            self.stackSize = 0

        def push(self, data):
            temp = StackObject(data)
            temp.next = self.top
            self.top = temp
            self.stackSize += 1

        def pop(self):
            if self.top is None:
                return None
            temp = self.top
            tempData = temp.data
            self.top = self.top.next
            del temp
            self.stackSize -= 1
            return tempData

        def size(self):
            return self.stackSize

        def empty(self):
            return self.stackSize == 0

        def on_top(self):
            if self.top is None:
                return None
            return self.top.data

if __name__ == '__main__':
    # algorytm sprawdzania poprawności nawiasów
    stack = Stack()
    str = input("Wprowadź ciąg znaków zawierający nawiasy: ")
    error = False

    for i in range(len(str)):
        # Sprawdzanie poprawności dla trzech typów nawiasów
        if str[i] == '(':
            stack.push('(')
        elif str[i] == ')':
            if stack.on_top() == '(':
                stack.pop()
            else:
                error = True
        elif str[i] == '{':
            stack.push('{')
        elif str[i] == '}':
            if stack.on_top() == '{':
                stack.pop()
            else:
                error = True
        elif str[i] == '[':
            stack.push('[')
        elif str[i] == ']':
            if stack.on_top() == '[':
                stack.pop()
            else:
                error = True

    if not error and stack.empty():
        print("Poprawnie zamknięte nawiasy")
    else:
        print("Niepoprawnie zamknięte nawiasy")