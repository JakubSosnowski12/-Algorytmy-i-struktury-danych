def evaluate_postfix(expression):
    stack = []
    for symbol in expression:
        if symbol.isdigit():
            stack.append(int(symbol))
        elif symbol == ' ':
            continue
        else:
            second_operand = stack.pop()
            first_operand = stack.pop()

            if symbol == '+':
                result = first_operand + second_operand
            elif symbol == '-':
                result = first_operand - second_operand
            elif symbol == '*':
                result = first_operand * second_operand
            elif symbol == '/':
                result = first_operand / second_operand
            elif symbol == '^':
                result = first_operand ** second_operand
            else:
                raise ValueError("Nieznany operator")

            stack.append(result)

    return stack.pop()
# Przykładowe użycie
expressions = [
    "2 2 +",
    "3 2 5 * +",
    "2 5 2 + *",
    "7 3 + 5 2 - 2 ^ *",
    "4 3 1 - 2 3 * ^ /",
    "7 3 + 5 2 - 2 ^ *"
]
for expression in expressions:
    result = evaluate_postfix(expression)
    print("Wartość wyrażenia", expression, "to:", result)