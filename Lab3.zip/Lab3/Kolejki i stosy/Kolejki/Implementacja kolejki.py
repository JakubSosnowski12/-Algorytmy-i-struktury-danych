class Queue:
    def __init__(self):
        self.items = []

    def is_empty(self):
        return len(self.items) == 0

    def enqueue(self, item):
        self.items.append(item)

    def dequeue(self):
        if self.is_empty():
            raise IndexError("Kolejka jest pusta.")
        return self.items.pop(0)

    def size(self):
        return len(self.items)

queue = Queue()

print(queue.is_empty())  # True

queue.enqueue(1)
queue.enqueue(2)
queue.enqueue(3)

print(queue.size())  # 3

print(queue.dequeue())  # 1
print(queue.dequeue())  # 2

print(queue.size())  # 1

print(queue.is_empty())  # False
