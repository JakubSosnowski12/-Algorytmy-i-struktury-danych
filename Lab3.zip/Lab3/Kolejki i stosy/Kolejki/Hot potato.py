import random

class QueueObject:
    def __init__(self, data):
        self.data = data
        self.next = None

class Queue:
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def enqueue(self, object):
        if self.head is None:
            self.head = object
            self.tail = object
        else:
            self.tail.next = object
            self.tail = object
        self.size += 1

    def dequeue(self):
        if self.head is None:
            return None
        temp = self.head
        self.head = self.head.next
        self.size -= 1
        return temp

    def isempty(self):
        return self.head is None

    def getSize(self):
        return self.size

def changePotatoPosition(kolejka):
    temp = kolejka.dequeue()
    kolejka.enqueue(temp)

ziemniak = Queue()
ziemniak.enqueue(QueueObject("Bill"))
ziemniak.enqueue(QueueObject("David"))
ziemniak.enqueue(QueueObject("Susan"))
ziemniak.enqueue(QueueObject("Jane"))
ziemniak.enqueue(QueueObject("Kent"))
ziemniak.enqueue(QueueObject("Brad"))
players = 6

while players > 1:
    for i in range(random.randint(0, players - 1)):
        changePotatoPosition(ziemniak)
    eliminated_player = ziemniak.dequeue()
    print(eliminated_player.data + " has been eliminated by potato.")
    players -= 1

print("The winner is " + ziemniak.dequeue().data)
