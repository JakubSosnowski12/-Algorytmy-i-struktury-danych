def oblicz_sume_tablicy(tablica):
    if len(tablica) == 0:
        return 0

    if len(tablica) == 1:
        return tablica[0]

    polowa = len(tablica) // 2
    lewa_polowa = tablica[:polowa]
    prawa_polowa = tablica[polowa:]

    suma_lewa = oblicz_sume_tablicy(lewa_polowa)
    suma_prawa = oblicz_sume_tablicy(prawa_polowa)

    return suma_lewa + suma_prawa
tablica = [1]
suma = oblicz_sume_tablicy(tablica)
print(suma)  # Wyświetli: 30
