from fractions import Fraction

def oblicz_P(i, j):
    # Inicjalizacja tablicy wynikowej
    P = [[Fraction(0, 1)] * (j + 1) for _ in range(i + 1)]

    # Wypełnienie wartości bazowych
    for x in range(i + 1):
        P[x][0] = Fraction(0, 1)
    for y in range(j + 1):
        P[0][y] = Fraction(1, 1)

    # Obliczanie wartości 𝑃(𝑖, 𝑗) dla 𝑖 > 0, 𝑗 > 0
    for x in range(1, i + 1):
        for y in range(1, j + 1):
            P[x][y] = P[x - 1][y] + P[x][y - 1]

    # Zwróć wartość 𝑃(𝑖, 𝑗)
    return P[i][j]

# Przykładowe użycie
i = 3
j = 3
wynik = oblicz_P(i, j)
print(f"Wartość P({i}, {j}): {wynik}")
