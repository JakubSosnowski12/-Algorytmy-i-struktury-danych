def kruskal(G):
    sorted_edges = sorted(G, key=lambda e: e[2])
    MST = []
    disjoint_sets = {v: v for edge in sorted_edges for v in edge[:2]}

    for edge in sorted_edges:
        u, v, weight = edge
        root_u = find_root(u, disjoint_sets)
        root_v = find_root(v, disjoint_sets)

        if root_u != root_v:
            MST.append(edge)
            disjoint_sets[root_u] = root_v

    return MST

def find_root(vertex, disjoint_sets):
    if disjoint_sets[vertex] != vertex:
        disjoint_sets[vertex] = find_root(disjoint_sets[vertex], disjoint_sets)
    return disjoint_sets[vertex]

G = [(6, 7, 1), (2, 4, 2), (7, 8, 2), (0, 1, 4), (2, 8, 4), (4, 7, 6), (2, 3, 7), (4, 6, 7), (0, 6, 8), (1, 2, 8), (3, 5, 9), (5, 8, 10), (1, 6, 11), (3, 8, 14)]

MST = kruskal(G)

print("MST Kruskala:")
for edge in MST:
    print(f"{edge[0]} - {edge[1]}, waga: {edge[2]}")
