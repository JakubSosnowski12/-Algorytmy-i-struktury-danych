import sys

def prim(G):
    num_vertices = len(G)
    key = [sys.maxsize] * num_vertices
    parent = [None] * num_vertices
    key[0] = 0
    visited = [False] * num_vertices

    for _ in range(num_vertices):
        min_key = sys.maxsize
        min_index = -1

        for i in range(num_vertices):
            if not visited[i] and key[i] < min_key:
                min_key = key[i]
                min_index = i

        visited[min_index] = True

        for j in range(num_vertices):
            if (
                G[min_index][j] != 0
                and not visited[j]
                and G[min_index][j] < key[j]
            ):
                key[j] = G[min_index][j]
                parent[j] = min_index

    MST = []
    for i in range(1, num_vertices):
        MST.append((parent[i], i, G[i][parent[i]]))

    return MST

G = [
    [0, 4, 0, 0, 8, 0, 0, 0, 0],
    [4, 0, 8, 0, 11, 0, 0, 0, 0],
    [0, 8, 0, 7, 0, 2, 0, 4, 0],
    [0, 0, 7, 0, 0, 0, 0, 14, 9],
    [8, 11, 0, 0, 0, 7, 1, 0, 0],
    [0, 0, 2, 0, 7, 0, 6, 0, 0],
    [0, 0, 0, 0, 1, 6, 0, 2, 0],
    [0, 0, 4, 14, 0, 0, 2, 0, 10],
    [0, 0, 0, 9, 0, 0, 0, 10, 0]
]


MST = prim(G)

print("MST Prima:")
for edge in MST:
    print(f"{edge[0]} - {edge[1]}, waga: {edge[2]}")
