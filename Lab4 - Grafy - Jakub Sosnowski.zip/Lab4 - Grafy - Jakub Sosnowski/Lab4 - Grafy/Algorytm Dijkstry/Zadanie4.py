import sys

def dijkstra(graph, start):
    # Inicjalizacja
    distance = {vertex: sys.maxsize for vertex in graph}
    distance[start] = 0
    visited = set()

    while len(visited) < len(graph):
        # Znajdowanie wierzchołka o najmniejszej odległości
        min_distance = sys.maxsize
        min_vertex = None

        for vertex in graph:
            if vertex not in visited and distance[vertex] < min_distance:
                min_distance = distance[vertex]
                min_vertex = vertex

        # Aktualizacja odległości dla sąsiadów wybranego wierzchołka
        for neighbor, weight in graph[min_vertex].items():
            new_distance = distance[min_vertex] + weight
            if new_distance < distance[neighbor]:
                distance[neighbor] = new_distance

        visited.add(min_vertex)

    return distance

# Przykład użycia
graph = {
    'A': {'B': 4, 'C': 2},
    'B': {'A': 4, 'C': 1, 'D': 5},
    'C': {'A': 2, 'B': 1, 'D': 8},
    'D': {'B': 5, 'C': 8}
}

start_vertex = 'A'
distances = dijkstra(graph, start_vertex)

print("Najkrótsze odległości od wierzchołka", start_vertex)
for vertex, distance in distances.items():
    print("Wierzchołek:", vertex, "Odległość:", distance)
