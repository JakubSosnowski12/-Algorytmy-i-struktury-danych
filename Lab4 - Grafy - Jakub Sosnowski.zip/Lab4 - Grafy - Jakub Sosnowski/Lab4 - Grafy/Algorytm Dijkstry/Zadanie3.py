import numpy as np
import networkx as nx
import matplotlib.pyplot as plt


def build_graph():
    print("Witaj w programie do budowania grafu!")

    while True:
        graph_type = input("Jakiego rodzaju graf chcesz zbudować? (skierowany/nieskierowany): ")
        if graph_type.lower() in ["skierowany", "nieskierowany"]:
            break
        else:
            print("Nieprawidłowy rodzaj grafu. Spróbuj ponownie.")

    num_vertices = int(input("Podaj liczbę wierzchołków w grafie: "))

    adjacency_matrix = np.zeros((num_vertices, num_vertices))

    if graph_type.lower() == "skierowany":
        print("Podaj połączenia pomiędzy wierzchołkami (kierunek od wierzchołka A do B) - oddzielone spacją:")
        print("Przykład: 0 1 oznacza połączenie z wierzchołka 0 do 1")
    else:
        print("Podaj połączenia pomiędzy wierzchołkami - oddzielone spacją:")
        print("Przykład: 0 1 oznacza połączenie między wierzchołkiem 0 i 1")

    while True:
        connection = input("Podaj połączenie (wpisz 'koniec', aby zakończyć): ")

        if connection.lower() == "koniec":
            break

        vertices = connection.split()
        if len(vertices) != 2:
            print("Nieprawidłowe połączenie. Spróbuj ponownie.")
            continue

        try:
            vertex_a = int(vertices[0])
            vertex_b = int(vertices[1])
        except ValueError:
            print("Nieprawidłowe połączenie. Wierzchołki powinny być liczbami. Spróbuj ponownie.")
            continue

        if vertex_a < 0 or vertex_a >= num_vertices or vertex_b < 0 or vertex_b >= num_vertices:
            print("Nieprawidłowe połączenie. Wierzchołki powinny mieścić się w zakresie 0-{}.".format(num_vertices - 1))
            continue

        adjacency_matrix[vertex_a][vertex_b] = 1

        if graph_type.lower() == "nieskierowany":
            adjacency_matrix[vertex_b][vertex_a] = 1

    print("Macierz sąsiedztwa:")
    print(adjacency_matrix)

    adjacency_list = adjacency_matrix.tolist()
    print("Lista sąsiedztwa:")
    print(adjacency_list)

    graph = nx.DiGraph() if graph_type.lower() == "skierowany" else nx.Graph()

    for i in range(num_vertices):
        for j in range(num_vertices):
            if adjacency_matrix[i][j] == 1:
                graph.add_edge(i, j)

    print("Interpretacja graficzna grafu:")
    nx.draw(graph, with_labels=True)
    plt.show()


build_graph()
